package br.com.delfeu.demoTarefas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTarefasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTarefasApplication.class, args);
	}

}
