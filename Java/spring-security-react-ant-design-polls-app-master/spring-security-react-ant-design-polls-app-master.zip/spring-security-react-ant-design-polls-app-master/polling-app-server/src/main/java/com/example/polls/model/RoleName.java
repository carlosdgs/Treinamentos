package com.example.polls.model;

/**
 * Created by rajeevkumarsingh on 07/12/17.
 */
public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN
}
